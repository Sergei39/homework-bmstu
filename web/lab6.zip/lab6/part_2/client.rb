# frozen_string_literal: true

require_relative 'logic'

puts "eps = 1e-3: n = #{integral(1e-3)}"
puts "eps = 1e-4: n = #{integral(1e-4)}"
