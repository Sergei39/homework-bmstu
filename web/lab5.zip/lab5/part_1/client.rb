# frozen_string_literal: true

require_relative 'logic'

puts 'Hello'

puts 'Input x'
x_num = gets.to_f

puts 'Input z'
z_num = gets.to_f

puts "Result: #{math_yr x_num, z_num}"
