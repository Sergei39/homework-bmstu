# frozen_string_literal: true

require_relative 'logic'

default_object = SymbolFont.new('b', 'TimeNewRoman')
puts default_object.sym
puts default_object.code
puts default_object.font
