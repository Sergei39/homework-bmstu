# frozen_string_literal: true

require_relative 'logic'

generate_file 'F', 50
new_text_from_file_into_file 'F', 'G'
